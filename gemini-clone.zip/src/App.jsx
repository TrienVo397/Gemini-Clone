import React from 'react'
import Sidebar from './components/Sidebar/Sidebar'

const App = () => {
  return (
    <>
      <Sidebar/>
    </>
  )
}

export default App
